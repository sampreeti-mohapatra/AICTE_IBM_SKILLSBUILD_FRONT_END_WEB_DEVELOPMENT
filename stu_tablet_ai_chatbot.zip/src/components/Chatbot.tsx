import React, { useState } from 'react';

const Chatbot: React.FC = () => {
  const [messages, setMessages] = useState<{ text: string; sender: string }[]>([]);
  const [input, setInput] = useState('');

  // Simulated AI response (replace with IBM Watson API for real AI)
  const sendMessage = async (msg: string) => {
    setMessages([...messages, { text: msg, sender: 'user' }]);
    setTimeout(() => {
      const aiResponse = `AI Agent: You asked "${msg}". This is a sample response.`;
      setMessages(prev => [...prev, { text: aiResponse, sender: 'ai' }]);
    }, 800);
  };

  return (
    <div style={{ border: '1px solid #ccc', padding: 16, borderRadius: 4, minWidth: 300 }}>
      <h3>Ask the AI Agent</h3>
      <div style={{ height: 180, overflowY: 'auto', marginBottom: 10, background: '#fafafa', padding: 8 }}>
        {messages.map((m, i) => (
          <div key={i} style={{ textAlign: m.sender === 'user' ? 'right' : 'left', margin: '6px 0' }}>
            <span style={{ background: m.sender === 'user' ? '#d1e7dd' : '#e2e3e5', padding: '6px 12px', borderRadius: 12 }}>
              {m.text}
            </span>
          </div>
        ))}
      </div>
      <input
        type="text"
        value={input}
        onChange={e => setInput(e.target.value)}
        placeholder="Type your question..."
        style={{ width: '70%', padding: 8, borderRadius: 4, border: '1px solid #ccc' }}
      />
      <button
        onClick={() => {
          if (input.trim()) {
            sendMessage(input);
            setInput('');
          }
        }}
        style={{ padding: '8px 16px', marginLeft: 8, borderRadius: 4, border: 'none', background: '#007bff', color: '#fff' }}
      >
        Send
      </button>
    </div>
  );
};

export default Chatbot;
import React, { useState } from 'react';

const contents = [
  { id: 1, title: 'Math Chapter 1', body: 'Introduction to Algebra...' },
  { id: 2, title: 'Science Chapter 1', body: 'Basics of Physics...' },
  { id: 3, title: 'English Chapter 1', body: 'Reading Comprehension...' },
];

const ContentViewer: React.FC = () => {
  const [selected, setSelected] = useState(contents[0]);

  return (
    <div style={{ minWidth: 300 }}>
      <h2>Subjects</h2>
      <ul style={{ listStyle: 'none', padding: 0 }}>
        {contents.map(content => (
          <li key={content.id} style={{ marginBottom: 10 }}>
            <button
              onClick={() => setSelected(content)}
              style={{
                padding: '8px 16px',
                background: selected.id === content.id ? '#007bff' : '#eee',
                color: selected.id === content.id ? '#fff' : '#333',
                border: 'none',
                borderRadius: 4,
                cursor: 'pointer'
              }}
            >
              {content.title}
            </button>
          </li>
        ))}
      </ul>
      <div style={{ marginTop: 20, background: '#f9f9f9', padding: 16, borderRadius: 4 }}>
        <h3>{selected.title}</h3>
        <p>{selected.body}</p>
      </div>
    </div>
  );
};

export default ContentViewer;
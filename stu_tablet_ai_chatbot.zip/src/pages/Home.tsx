import React from 'react';
import ContentViewer from '../components/ContentViewer';
import Chatbot from '../components/Chatbot';

const Home: React.FC = () => {
  return (
    <div style={{ padding: 20, fontFamily: 'Arial, sans-serif' }}>
      <h1>Welcome to Student Tablet App</h1>
      <div style={{ display: 'flex', gap: 40 }}>
        <ContentViewer />
        <Chatbot />
      </div>
    </div>
  );
};

export default Home;